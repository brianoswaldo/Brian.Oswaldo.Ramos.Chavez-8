#include "project.h"
#include <stdio.h> //libreria necesaria para la funcion sprintf
#include <math.h>
#include <project.h>

int32 entero,voltaje; //variables necesarias para la lectura del ADC
float32 temp,conv; //variable para la conversion de voltaje a temperatura
char str[16]; // variable para la conversion de float a char

int main()
{
    CyGlobalIntEnable; //interrupciones globales
    uint8 i;
    float Lux;
    float32 con1,con2;
    LCD_Start(); //inicialización de el bloque LCD
    Opamp_Start(); //inicialización del amplificador operacional
    ADC_Start(); //inicializacion del bloque ADC
    
    LCD_Position(0,0); //posicionamiento en LCD
    LCD_PrintString("Temperatura");// imprimir mensaje 
    

    for(;;)
    {
       ADC_StartConvert(); //iniciar conversiones del ADC
       ADC_IsEndConversion(ADC_WAIT_FOR_RESULT); //Esperar por el resultado del ADC
       entero = ADC_GetResult32();  //obtener el valor entero del ADC
       ADC_StopConvert();// detener conversiones
    
       voltaje = ADC_CountsTo_mVolts(entero);// convertir de enteros a milivolts
    
       temp=(voltaje/10.00)-8; //division de voltaje para la temperatura y acondicionamiento por calibracion
    
       sprintf(str,"%.1f",temp); //conversion de variable float a char para conversion
    
       LCD_Position(1,4); //posicionamiento de la LCD
       LCD_PrintString(str); //imprimir variable de temperatura
       LCD_PutChar(LCD_CUSTOM_0); //imprimir caracter custom de la LCD (°)
       LCD_PrintString("C   "); //imprimir letra C de grados centígrados
    
    }
}